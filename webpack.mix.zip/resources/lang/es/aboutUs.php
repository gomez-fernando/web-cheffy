<?php

return [

    /*
    |--------------------------------------------------------------------------
    |Traducciones de la pagina aboutUs
    |
    */

    '10' => 'Sobre nosotros',
    '20' => 'Somos una empresa joven y en plena expansión con sede en Marbella',
    '30' => 'Recientemente hemos ganado el concurso de la Cámara de Comercio de Marbella por nuestra iniciativa de servicios',
    '40' => 'Nuestra misión es dar a conocer al mundo las maravillas gastronómicas y la cultura de ésta región.',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',

];
