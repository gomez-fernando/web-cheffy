<?php

return [

    /*
    |--------------------------------------------------------------------------
    |Traducciones de la pagina catalog
    |
    */

    '10' => 'En Cheffy colaboramos con los mejores sitios de Marbella para ofrecerte experiencias únicas.',
    '20' => 'Cheffs apasionados y restaurantes premiados por su calidad te están esperando en tu próxima escapada.',
    '30' => 'También sitios con encanto en medio de la nada.',
    '40' => 'Descubre joyas culinarias escondidas',
    '50' => 'Una deliciosa cata de vinos y tapas',
    '60' => 'El mar como seña de identidad',
    '70' => 'Disfrutar de un paseo por la finca y conocer nuestro rebaño de cabras',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',

];
