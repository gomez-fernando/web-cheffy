<?php

return [

    /*
    |--------------------------------------------------------------------------
    |Traducciones de la pagina catalog
    |
    */

    '40' => 'Descubre joyas culinarias escondidas',
    '50' => 'Una deliciosa cata de vinos y tapas',
    '60' => 'El mar como seña de identidad',
    '70' => 'Disfrutar de un paseo por la finca y conocer nuestro rebaño de cabras',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',

];
