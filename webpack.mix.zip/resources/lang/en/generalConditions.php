<?php

return [

    /*
    |--------------------------------------------------------------------------
    |Traducciones de la pagina de condiciones generales
    |
    */

    'about_us' => 'About us',

];
