<?php

return [

    /*
    |--------------------------------------------------------------------------
    |Traducciones de la pagina aboutUs
    |
    */

    '10' => 'Sobre nosotros',
    '20' => 'Tenemos nuestra sede en Marbella. Somos una empresa joven y en plena expansión.',

    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',
    '8u8u' => 'Descubre joyas culinarias escondidas',

];
