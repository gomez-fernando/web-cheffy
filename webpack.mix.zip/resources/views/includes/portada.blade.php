<div class="contenido-header">
    <div class="fondo" id="fondo">
        <h1 class="texto">Cheffy</h1>
    </div>
</div>
