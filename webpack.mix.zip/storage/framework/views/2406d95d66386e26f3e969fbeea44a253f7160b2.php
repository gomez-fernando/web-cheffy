<?php $__env->startSection('title'); ?>
    <title>Viajes personalizados</title>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('includes.navbarHome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

    <main class="container">

        <span class="anchor" id="services"></span>
        <div class="row productos">
            <article class="col-12 text-center">
                <h2 class="subtitulo"><span><?php echo e(__('lang.discover')); ?></span></h2>
                <p class="titulo"><?php echo e(__('lang.product1_tittle')); ?></p>
                <p><?php echo e(__('lang.product1_description_1')); ?></p>
            </article>

            <!-- <div class="col-md-6 col-12"> -->
            <div class="row justify-content-center">
                <article class="col-12 col-md-6   py-1">
                    <figure class="producto">
                        <img src="img/products/pr-1.jpg" class="img-fluid" alt="">

                    </figure>
                </article>
                <!-- </div> -->
            </div>
            <article class="col-12 text-center">
                <p><?php echo e(__('lang.product1_description_2')); ?></p>
            </article>

        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\web-cheffy\resources\views/products/product1.blade.php ENDPATH**/ ?>