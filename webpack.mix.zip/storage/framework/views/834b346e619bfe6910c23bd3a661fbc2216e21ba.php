<?php $__env->startSection('title'); ?>
    <title><?php echo e(__('generalConditions.title')); ?></title>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('includes.navbarHome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1><?php echo e(__('generalConditions.10')); ?></h1>
        <h2><?php echo e(__('generalConditions.20')); ?></h2>
        <p class="info-text"><?php echo e(__('generalConditions.30')); ?><br>
            <?php echo e(__('generalConditions.40')); ?><br>
            <?php echo e(__('generalConditions.50')); ?><br>
            <?php echo e(__('generalConditions.60')); ?></p>
        <h2><?php echo e(__('generalConditions.70')); ?></h2>
        <p class="info-text"><?php echo e(__('generalConditions.80')); ?><br>
            <?php echo e(__('generalConditions.90')); ?><br>
            &nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('generalConditions.100')); ?><br>
            &nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('generalConditions.110')); ?><br>
            &nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__('generalConditions.120')); ?><br>
            <?php echo e(__('generalConditions.130')); ?><br>
            <?php echo e(__('generalConditions.140')); ?></p>
        <p class="info-text"><?php echo e(__('generalConditions.150')); ?></p>
        <p class="info-text"><?php echo e(__('generalConditions.160')); ?></p>
        <p class="info-text"><?php echo e(__('generalConditions.170')); ?></p>
        <p class="info-text"><?php echo e(__('generalConditions.180')); ?></p>
        <p class="info-text"><?php echo e(__('generalConditions.190')); ?> <a href="<?php echo e(route('importantInfo.customerService')); ?>"><?php echo e(__('generalConditions.200')); ?></a></p>
    </div>
    <span class="anchor" id=""></span>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\web-cheffy\resources\views/importantInfo/generalConditions.blade.php ENDPATH**/ ?>