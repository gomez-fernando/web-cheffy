<?php $__env->startSection('title'); ?>
    <title><?php echo e(__('lang.210')); ?></title>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('includes.navbarHome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

    <main class="container">

        <span class="anchor" id="services"></span>
        <div class="row productos">
            <article class="col-12 text-center">
                <h2 class="subtitulo"><span><?php echo e(__('lang.we_provide')); ?></span></h2>
                <p class="titulo"><?php echo e(__('lang.our_products')); ?></p>
                <p><?php echo e(__('catalog.10')); ?></p>
                <p><?php echo e(__('catalog.20')); ?></p>
                <p><?php echo e(__('catalog.30')); ?></p>
            </article>

            <div class="col-md-6 col-12">
                <div class="row justify-content-center">
                    <article class="col-12   py-1">
                        <a href="<?php echo e(route('products.product1')); ?>">
                            <figure class="producto">
                                <img src="<?php echo e(asset('img/products/pr-1.jpg')); ?>" class="img-fluid" alt="">
                                <figcaption class="overlay">
                                    <p class="overlay-texto"><?php echo e(__('catalog.40')); ?></p>
                                </figcaption>
                            </figure>
                        </a>
                    </article>
                </div>
            </div>

            <div class="col-md-6 col-12">
                <div class="row justify-content-center">
                    <article class="col-12 py-1">
                        <a href="<?php echo e(route('products.product2')); ?>">
                            <figure class="producto">
                                <img src="<?php echo e(asset('img/products/pr-2.jpg')); ?>" class="img-fluid" alt="">
                                <figcaption class="overlay">
                                    <p class="overlay-texto"><?php echo e(__('catalog.50')); ?></p>
                                </figcaption>
                            </figure>
                        </a>
                    </article>
                </div>
            </div>

            <div class="col-md-6 col-12">
                <div class="row justify-content-center">
                    <article class="col-12 py-1">
                        <a href="<?php echo e(route('products.product3')); ?>">
                            <figure class="producto">
                                <img src="<?php echo e(asset('img/products/pr-3.jpg')); ?>" class="img-fluid" alt="">
                                <figcaption class="overlay">
                                    <p class="overlay-texto"><?php echo e(__('catalog.60')); ?></p>
                                </figcaption>
                            </figure>
                        </a>
                    </article>
                </div>
            </div>

            <div class="col-md-6 col-12">
                <div class="row justify-content-center">
                    <article class="col-12 py-1">
                        <a href="<?php echo e(route('products.product4')); ?>">
                            <figure class="producto">
                                <img src="<?php echo e(asset('img/products/pr-4.jpg')); ?>" class="img-fluid" alt="">
                                <figcaption class="overlay">
                                    <p class="overlay-texto"><?php echo e(__('catalog.70')); ?></p>
                                </figcaption>
                            </figure>
                        </a>
                    </article>
                </div>
            </div>

        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\web-cheffy\resources\views/products/catalog.blade.php ENDPATH**/ ?>