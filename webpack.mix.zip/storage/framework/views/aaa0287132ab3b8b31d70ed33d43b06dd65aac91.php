
<?php if(session('message')): ?>
    <?php if(session('status') == 'error'): ?>
    <div class="alert alert-danger">
        <?php echo e(session('message')); ?>

    </div>
    <?php else: ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>
    <!-- <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div> -->
<?php endif; ?>


<?php /**PATH C:\wamp64\www\web-cheffy\resources\views/includes/message.blade.php ENDPATH**/ ?>