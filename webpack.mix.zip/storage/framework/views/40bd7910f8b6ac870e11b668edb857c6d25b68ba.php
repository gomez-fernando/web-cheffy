<?php $__env->startSection('title'); ?>
    <title>Cheffy</title>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('includes.navbarHome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <main class="container">
        <div class="productos">
            <div class="row justify-content-center mb-3">
                <h1 ><?php echo e(__('aboutUs.10')); ?></h1>
            </div>
            <div class="row  justify-content-center">
                <figure>
                    <img src="<?php echo e(asset('img/logo.png')); ?>" class="in-page-cheffy-logo" alt="">
                </figure>
            </div>
            <div class="row justify-content-center px-5 ">
                <p class="info-text"><?php echo e(__('aboutUs.20')); ?></p>
                <p class="info-text"><?php echo e(__('aboutUs.30')); ?></p>
                <p class="info-text"><?php echo e(__('aboutUs.40')); ?></p>
            </div>

        </div>



    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\web-cheffy\resources\views/aboutUs/aboutUs.blade.php ENDPATH**/ ?>